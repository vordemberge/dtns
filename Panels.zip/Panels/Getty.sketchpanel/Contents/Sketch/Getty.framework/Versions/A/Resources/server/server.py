import BaseHTTPServer, SimpleHTTPServer
import ssl
import os
import sys

HOST_NAME = '127.0.0.1'
PORT_NUMBER = 24686
CERTFILE_PATH = 'cert.pem'
KYEFILE_PATH = 'key.pem'
ADDRESS_ALREADY_IN_USE_ERROR_CODE = 48
AUTH_REDIRECT_PATH = './auth-redirect.html'

class Handler(BaseHTTPServer.BaseHTTPRequestHandler):
    def do_GET(self):
        print(self.path);
        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        f = open(AUTH_REDIRECT_PATH)
        self.wfile.write(f.read())
        f.close()

    def log_message(self, format, *args):
        return

dirname = os.path.dirname(__file__)

try:
    web_server = BaseHTTPServer.HTTPServer((HOST_NAME, PORT_NUMBER), Handler)
    web_server.socket = ssl.wrap_socket(web_server.socket, server_side=True, certfile=os.path.join(dirname, CERTFILE_PATH), keyfile=os.path.join(dirname, KYEFILE_PATH))
    web_server.serve_forever()

except Exception as e:
  if e.args[0] != ADDRESS_ALREADY_IN_USE_ERROR_CODE:
    raise e
