
/bin/kill $(ps aux | grep 'Getty.framework/Resources/server/server.py' | grep '/usr/bin/python' | awk '{print $2}')
