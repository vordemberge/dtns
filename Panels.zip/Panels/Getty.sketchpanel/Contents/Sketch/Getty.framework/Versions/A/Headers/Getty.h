//
//  Getty.h
//  Getty
//
//  Created by Tomáš Přívora on 30/08/16.
//  Copyright © 2016 InVision LABS. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for Getty.
FOUNDATION_EXPORT double GettyVersionNumber;

//! Project version string for Getty.
FOUNDATION_EXPORT const unsigned char GettyVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Getty/PublicHeader.h>


