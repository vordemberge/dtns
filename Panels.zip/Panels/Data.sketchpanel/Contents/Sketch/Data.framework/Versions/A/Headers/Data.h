//
//  Data.h
//  Data
//
//  Created by Tomáš Hanáček on 5/24/16.
//  Copyright © 2016 InVision LABS. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for Data.
FOUNDATION_EXPORT double DataVersionNumber;

//! Project version string for Data.
FOUNDATION_EXPORT const unsigned char DataVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Data/PublicHeader.h>


