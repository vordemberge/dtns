!function(e, t) {
    if ("object" == typeof exports && "object" == typeof module) module.exports = t(); else if ("function" == typeof define && define.amd) define([], t); else {
        var r = t();
        for (var n in r) ("object" == typeof exports ? exports : e)[n] = r[n];
    }
}(this, function() {
    return function(e) {
        function t(n) {
            if (r[n]) return r[n].exports;
            var o = r[n] = {
                exports: {},
                id: n,
                loaded: !1
            };
            return e[n].call(o.exports, o, o.exports, t), o.loaded = !0, o.exports;
        }
        var r = {};
        return t.m = e, t.c = r, t.p = "", t(0);
    }([ function(e, t, r) {
        "use strict";
        function n(e) {
            if (e && e.__esModule) return e;
            var t = {};
            if (null != e) for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
            return t.default = e, t;
        }
        function o(e) {
            var t = e.selection;
            e.panel.callback({
                count: j.getLayersCount(t)
            });
        }
        function i(e, t) {
            var r = t.selection, n = t.panel, o = t.command, i = j.flatten((0, _.getArray)(e.symbolMaster().layers())), a = O.map(i, function(e) {
                return e.layer.name();
            }), l = n.api().showSelectSymbolOverrideWindow(a);
            if (l > -1) {
                var s = i.objectAtIndex(l), u = s.layer, c = s.path, d = t.panel.arguments().words, f = d.count(), S = n.arguments(), y = S.action;
                y && o.setValue_forKey_onLayer_forPluginIdentifier(y, "type-duplicate", u, C.DUPLICATE_IDENTIFIER);
                var p = 0;
                (0, _.iterate)(r, function(e) {
                    var t = d[p % f];
                    if (O.symbol.addOverrides(e, t, c), e.overrides && e.setOverrides) {
                        var r = e.overrides();
                        e.setOverrides(r);
                    }
                    p += 1;
                });
            }
        }
        function a(e) {
            var t = e.selection, r = e.command, n = e.panel, o = n.api();
            t = j.filterLayers(t, o);
            var a = t.count();
            if (0 === a) return void (0, _.showAlert)("Please select text layer...");
            var l = NSMutableArray.alloc().init();
            if ((0, _.iterate)(t, function(t) {
                return (0, _.isSymbol)(t) ? i(t, e) : void l.addObject(t);
            }), !(l.count() < 1)) {
                var s = l.firstObject();
                if (s.isEditingText()) return void (0, _.showAlert)("You need to exit editing mode before using Type plugin.");
                var u = n.arguments(), c = u.words, d = u.action, f = !1;
                if (d) {
                    r.setValue_forKey_onLayer_forPluginIdentifier(d, "type-duplicate", s, C.DUPLICATE_IDENTIFIER);
                    var S = d.action;
                    if (S) if (S.isEqualToString("article")) {
                        var y = d.options;
                        if (y) {
                            var p = y.type;
                            p.isEqualToString("body") && (f = !0);
                        }
                    } else if (S.isEqualToString("khaled")) {
                        var v = d.options;
                        v.isEqualToString("article") && (f = !0);
                    }
                }
                if (c) {
                    var m = c.count(), g = 0;
                    (0, _.iterate)(l, function(e) {
                        var t = c[g % m];
                        j.set(e, t, f), f && j.setFixed(e), g += 1;
                    });
                }
            }
        }
        function l(e, t) {
            var r = e.document, n = e.command, o = A.filterLayers(e.selection), i = o.count(), a = e.panel, l = a.api(), s = a.identifier(), u = a.arguments();
            u || (u = a.settings()), t || (t = u.mode);
            var c = u.folder, d = u.link, f = u.category;
            if (0 === i) return void (0, _.showAlert)("Please select layer. Selecting groups is not supported.");
            var S = O.action.get(r, "MSInsertVectorAction");
            if (S.isActive()) return void (0, _.showAlert)('Please exit the shape "Edit" mode.');
            var y = o[0], p = void 0;
            if ((0, _.isSymbol)(y)) {
                var v = h((0, _.getArray)(y.symbolMaster().layers())), m = O.map(v, function(e) {
                    return e.layer.name();
                }), g = a.api().showSelectSymbolOverrideWindow(m), b = void 0;
                if (g > -1) {
                    var M = v.objectAtIndex(g);
                    p = M.path, b = M.layer;
                }
                if (!b) return void (0, _.showAlert)("Please select one layer inside the symbol.");
                var P = b.style().fills().firstObject();
                null == P && (P = b.style().addStylePartOfType(0)), P.setFillType(4), P.setPatternFillType(1);
            }
            if (!(0, _.isSymbol)(y)) {
                var j = NSDictionary.dictionaryWithDictionary(u);
                n.setValue_forKey_onLayer_forPluginIdentifier(j, "photos-duplicate", y, C.DUPLICATE_IDENTIFIER);
            }
            if (t.isEqualToString("link") || t.isEqualToString("dropbox")) {
                if (!d) return void (0, _.showAlert)("Please Paste link...");
                r.showMessage("Downloading image from Dropbox. It may take some time"), p ? l.dropbox_selection_ancestorIDs_identifier(d, o, p, s) : l.dropbox_selection_identifier(d, o, s);
            } else if (t.isEqualToString("unsplash")) r.showMessage("Downloading image from Unsplash. It may take some time"), 
            p ? l.unsplashWithSelection_ancestorIDs_category_identifier(o, p, f, s) : l.unsplashWithSelection_category_identifier(o, f, s); else {
                if (!c) return void (0, _.showAlert)("Please Select folder...");
                p ? l.imagesFromFolder_applyToLayers_ancestorIDs_identifier(c, o, p, s) : l.imagesFromFolder_applyToLayers_identifier(c, o, s);
            }
        }
        function s(e) {
            l(e, NSString.stringWithString("folder"));
        }
        function u(e) {
            l(e, NSString.stringWithString("link"));
        }
        function c(e) {
            l(e, NSString.stringWithString("unsplash"));
        }
        function d(e) {
            var t = e.panel, r = t.arguments(), n = r.initialFolder, o = NSOpenPanel.openPanel();
            if (o.setCanChooseFiles(!1), o.setCanChooseDirectories(!0), n) {
                var i = NSURL.fileURLWithPath_isDirectory(n, !0);
                o.setDirectoryURL(i);
            }
            if (o.runModal() === NSFileHandlingPanelOKButton) {
                var a = o.URLs().lastObject();
                t.callback({
                    path: a.path()
                });
            }
        }
        function f(e) {
            var t = e.panel, r = e.document.currentPage(), n = e.command, o = n.valueForKey_onLayer_forPluginIdentifier("json-files", r, t.identifier());
            o || (o = JSON.stringify([])), t.callback(o);
        }
        function S(e, t, r) {
            var n = e.document.currentPage(), o = e.command, i = e.panel, a = L.createFile(i, o, n, t, r), l = a.file, s = a.files;
            (0, _.iterate)(e.selection, function(e) {
                L.setMetaData(i.identifier(), o, e, [], l.path, l.name);
            }), i.callback_forIdentifier(s, "get-json-files"), i.callback_forIdentifier(l, "on-json-change");
        }
        function y(e) {
            var t = String(e.panel.arguments()), r = JSON.parse(t);
            S(e, r.json, r.name);
        }
        function p(e) {
            var t = NSOpenPanel.openPanel();
            if (t.setCanChooseFiles(!0), t.setCanChooseDirectories(!1), t.runModal() === NSFileHandlingPanelOKButton) {
                var r = t.URLs().lastObject(), n = ICUtils.readJSON(r);
                if (n) {
                    var o = r.lastPathComponent();
                    S(e, n, o);
                } else e.panel.callback({
                    error: !0
                });
            }
        }
        function v(e) {
            var t = e.panel, r = e.command, n = e.selection, o = {
                paths: {
                    selection: null,
                    repeat: null
                }
            };
            t.callback(o);
            var i = null, a = !0, l = void 0;
            (0, _.iterate)(n, function(e) {
                return l = r.valueForKey_onLayer_forPluginIdentifier("json-plugin-data", e, t.identifier()), 
                l && !a && i !== l ? (l = null, !1) : (i = l, void (a = !1));
            }), l && t.callback(l);
        }
        function m(e) {
            var t = e.command, r = e.panel;
            (0, _.iterate)(e.selection, function(e) {
                t.setValue_forKey_onLayer_forPluginIdentifier("null", "json-plugin-data", e, r.identifier());
            });
        }
        function g(e) {
            var t = null != NSClassFromString("MSShapePathLayer"), r = e.class() === MSShapeGroup;
            return t ? e.isKindOfClass(MSShapePathLayer) || r : r;
        }
        function h(e, t) {
            var r = NSMutableArray.alloc().init();
            return (0, _.iterate)(e, function(e) {
                var n = NSMutableArray.alloc().init();
                null != t && n.addObjectsFromArray(t), g(e) ? (n.addObject(e.objectID()), r.addObject({
                    layer: e,
                    path: n
                })) : j.isSymbol(e) ? (n.addObject(e.objectID()), r.addObjectsFromArray(h(e.symbolMaster().layers(), n))) : j.isGroup(e) && r.addObjectsFromArray(h(e.layers()));
            }), r;
        }
        function b(e) {
            var t = NSMutableArray.alloc().init();
            return (0, _.iterate)(e, function(e) {
                g(e) ? t.addObject(e) : j.isSymbol(e) ? t.addObjectsFromArray(b(e.symbolMaster().layers())) : j.isGroup(e) && t.addObjectsFromArray(b(e.layers()));
            }), t;
        }
        function M(e) {
            var t = e.panel, r = t.api(), n = String(t.arguments()), o = e.command, i = e.selection, a = JSON.parse(n), l = a.firstValue, s = a.values, u = a.paths, c = a.file, d = a.name;
            if (0 !== i.count()) {
                0 !== i.count() && 0 !== s.length || (s = [ l ]);
                var f = /[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&\/\/=]*)/gi, S = j.isSymbol(i.firstObject()), y = !j.isTextLayer(i.firstObject()), p = f.test(s[0] || l), v = 0;
                if (S) p ? (0, _.iterate)(i, function(e) {
                    var n = b(e.symbolMaster().layers()), i = t.api().showSelectSymbolOverrideWindow(n.valueForKey("name"));
                    i > -1 && (L.setMetaData(t.identifier(), o, e, u, c, d), r.downloadImages_applyToLayers_startIndex_identifier(s, [ n.objectAtIndex(i) ], v++ % s.length, t.identifier()));
                }) : (0, _.iterate)(i, function(e) {
                    var r = j.flatten(e.symbolMaster().layers()), n = O.map(r, function(e) {
                        return e.layer.name();
                    }), i = t.api().showSelectSymbolOverrideWindow(n);
                    if (i > -1) {
                        var a = r.objectAtIndex(i).path, l = s[v++ % s.length];
                        O.symbol.addOverrides(e, l, a), L.setMetaData(t.identifier(), o, e, u, c, d);
                    }
                }); else if (y) (0, _.iterate)(i, function(e) {
                    L.setMetaData(t.identifier(), o, e, u, c, d);
                }), r.downloadImages_applyToLayers_startIndex_identifier(s, i, 0, t.identifier()); else {
                    var m = 0;
                    (0, _.iterate)(i, function(e) {
                        L.setupLayer(t.identifier(), o, e, s[m++ % s.length], u, c, d);
                    });
                }
            }
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.textLayersCount = o, t.fillText = a, t.fillPhoto = l, t.fillPhotoFolder = s, 
        t.fillPhotoDropbox = u, t.fillPhotoUnsplash = c, t.openFolderDialog = d, t.getJSONFiles = f, 
        t.newJSONFile = y, t.chooseFile = p, t.jsonUpdateActiveFields = v, t.jsonClearSelectedValue = m, 
        t.jsonSendValues = M;
        var _ = r(1), O = n(_), P = (r(10), r(11)), j = n(P), T = r(12), A = n(T), I = r(13), L = n(I), C = r(14);
    }, function(e, t, r) {
        "use strict";
        function n(e) {
            if (e && e.__esModule) return e;
            var t = {};
            if (null != e) for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
            return t.default = e, t;
        }
        function o(e, t) {
            for (var r = e.objectEnumerator(), n = void 0; (n = r.nextObject()) && t(n) !== !1; ) ;
        }
        function i(e, t) {
            var r = NSMutableArray.alloc().init();
            return o(e, function(e) {
                r.addObject(t(e));
            }), r;
        }
        function a(e, t) {
            var r = NSMutableArray.alloc().init();
            return o(e, function(e) {
                t(e) && r.addObject(e);
            }), r;
        }
        function l(e, t) {
            var r = NSPredicate.predicateWithFormat("self isMemberOfClass: %@", t);
            return e.filteredArrayUsingPredicate(r);
        }
        function s(e) {
            return Math.round(100 * e) / 100;
        }
        function u(e, t, r) {
            var n = e[t];
            return void 0 === n || null === n ? r : n;
        }
        function c(e) {
            return e.class() === MSSymbolInstance;
        }
        function d(e) {
            return e.class() === MSSymbolMaster;
        }
        function f(e) {
            return e.class() === MSTextLayer;
        }
        function S(e) {
            var t = e.r, r = e.g, n = e.b, o = e.a;
            return MSColor.colorWithRed_green_blue_alpha(t, r, n, o);
        }
        function y(e) {
            return "function" == typeof e.array ? e.array() : e;
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.symbol = t.color = t.action = t.doc = t.page = t.layer = t.pasteboard = t.showConfirm = t.showAlert = void 0, 
        t.iterate = o, t.map = i, t.filter = a, t.filterArrayByClass = l, t.round100 = s, 
        t.get = u, t.isSymbol = c, t.isSymbolMaster = d, t.isTextLayer = f, t.rgbaToMSColor = S, 
        t.getArray = y;
        var p = r(2);
        Object.defineProperty(t, "showAlert", {
            enumerable: !0,
            get: function() {
                return p.showAlert;
            }
        }), Object.defineProperty(t, "showConfirm", {
            enumerable: !0,
            get: function() {
                return p.showConfirm;
            }
        });
        var v = r(3), m = n(v), g = r(4), h = n(g), b = r(6), M = n(b), _ = r(7), O = n(_), P = r(8), j = n(P), T = r(5), A = n(T), I = r(9), L = n(I);
        t.pasteboard = m, t.layer = h, t.page = M, t.doc = O, t.action = j, t.color = A, 
        t.symbol = L;
    }, function(e, t) {
        "use strict";
        function r(e) {
            var t = NSAlert.alloc().init();
            t.setAlertStyle(o.NSWarningAlertStyle), t.setMessageText(e), t.runModal();
        }
        function n(e, t) {
            var r = NSAlert.alloc().init();
            return r.addButtonWithTitle("OK"), r.addButtonWithTitle("Cancel"), r.setInformativeText(t), 
            r.setMessageText(e), r.runModal() === NSAlertFirstButtonReturn;
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.showAlert = r, t.showConfirm = n;
        var o = {
            NSWarningAlertStyle: 0,
            NSInformationalAlertStyle: 1,
            NSCriticalAlertStyle: 2
        };
    }, function(e, t) {
        "use strict";
        function r(e) {
            var t = NSPasteboard.generalPasteboard();
            t.declareTypes_owner([ NSPasteboardTypeString ], null), t.setString_forType(e, NSPasteboardTypeString);
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.writeString = r;
    }, function(e, t, r) {
        "use strict";
        function n(e) {
            if (e && e.__esModule) return e;
            var t = {};
            if (null != e) for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
            return t.default = e, t;
        }
        function o(e, t) {
            t.addLayer(e);
        }
        function i(e, t) {
            var r = NSBezierPath.bezierPathWithRect(e), n = MSShapeGroup;
            return "function" == typeof MSPath.pathWithBezierPath && (r = MSPath.pathWithBezierPath(r)), 
            n = "function" == typeof MSShapeGroup.shapeWithBezierPath ? MSShapeGroup.shapeWithBezierPath(r) : MSShapeGroup.layerWithPath(r), 
            o(n, t), "function" == typeof n.embedInShapeGroup && (n = n.embedInShapeGroup()), 
            n;
        }
        function a(e) {
            var t = MSTextLayer.alloc().initWithFrame(CGRectMake(0, 0, 100, 100));
            return t.adjustFrameToFit(), o(t, e), t;
        }
        function l(e, t) {
            var r = MSLayerGroup.alloc().initWithFrame(e);
            return o(r, t), r;
        }
        function s(e, t, r) {
            var n = e.style(), o = n.borders(), i = void 0;
            i = "function" == typeof o.addNewStylePart ? o.addNewStylePart() : n.addStylePartOfType(1);
            var a = f.fromString(t);
            i.setColor(a), i.setPosition(r);
        }
        function u(e) {
            e && e.removeFromParent();
        }
        function c(e, t, r) {
            var n = e.userInfo().objectForKey(t);
            if (n) return n.objectForKey(r);
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.addToGroup = o, t.addRectangleLayerToGroup = i, t.addTextLayerToGroup = a, 
        t.addGroupToGroup = l, t.addBorder = s, t.removeFromParent = u, t.getUserInfoValue = c;
        var d = r(5), f = n(d);
    }, function(e, t) {
        "use strict";
        function r(e) {
            if ("function" == typeof MSColor.colorWithSVGString) return MSColor.colorWithSVGString(e);
            var t = MSImmutableColor.colorWithSVGString(e);
            return MSColor.alloc().initWithImmutableObject(t);
        }
        function n(e) {
            var t = MSImmutableColor.colorWithSVGString(e);
            return t.NSColorWithColorSpace(NSColorSpace.genericRGBColorSpace());
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.fromString = r, t.nsColorFromString = n;
    }, function(e, t) {
        "use strict";
        function r(e, t) {
            for (var r = e.artboards(), n = r.count() - 1; n >= 0; n--) {
                var o = r[n];
                if (o.name().isEqualToString(t)) return o;
            }
        }
        function n(e, t, r) {
            if (e.artboards().count() > r) {
                var n = e.artboards()[r];
                if (n.name().isEqualToString(t)) return n;
            }
        }
        function o(e, t, r) {
            var n = MSArtboardGroup.alloc().initWithFrame(r);
            return e.addLayers([ n ]), n.setName(t), n;
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.getArtboardFromName = r, t.getArtboardFromNameAndIndex = n, t.addArtboard = o;
    }, function(e, t, r) {
        "use strict";
        function n(e) {
            if (e && e.__esModule) return e;
            var t = {};
            if (null != e) for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
            return t.default = e, t;
        }
        function o(e, t) {
            var r = e.addBlankPage();
            return r.setName(t), e.setCurrentPage(r), r;
        }
        function i(e, t) {
            for (var r = e.pages(), n = r.count() - 1; n >= 0; n--) {
                var o = r[n];
                if (o.name().isEqualToString(t)) return o;
            }
        }
        function a(e) {
            return "function" == typeof e.currentView ? e.currentView() : e.contentDrawView();
        }
        function l(e, t) {
            var r = a(e);
            t.select_byExpandingSelection(!0, !1), "function" == typeof r.zoomToSelection ? r.zoomToSelection() : c.zoomToSelection(e), 
            t.select_byExpandingSelection(!1, !1);
        }
        function s(e) {
            var t = a(e);
            "function" == typeof t.actualSizeWithoutAnimating ? t.actualSizeWithoutAnimating() : t.zoomToActualSizeAnimated(!1), 
            t.animateScrollOriginToPoint(CGPointMake(100, 100));
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.addPage = o, t.getPageFromName = i, t.zoomTo = l, t.zoom100Center = s;
        var u = r(8), c = n(u);
    }, function(e, t) {
        "use strict";
        function r(e, t) {
            var r = e.actionsController();
            return "function" == typeof r.actionWithName ? r.actionWithName(t) : "function" == typeof r.actionWithID ? r.actionWithID(t) : r.actionForID(t);
        }
        function n(e) {
            var t = r(e, "MSGroupAction");
            t.group(null);
            var n = e.selectedLayers(), o = void 0;
            return o = "function" == typeof n.firstObject ? n.firstObject() : n.firstLayer();
        }
        function o(e, t) {
            var n = t.name(), o = r(e, "MSClippingMaskAction");
            o.clippingMask(null), t.setName(n);
        }
        function i(e) {
            var t = r(e, "MSZoomToSelectionAction");
            t.zoomToSelection(null);
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.get = r, t.groupSelection = n, t.toggleClipping = o, t.zoomToSelection = i;
    }, function(e, t) {
        "use strict";
        function r(e, t, r) {
            if ("function" == typeof e.addOverrides_forCellAtIndex_ancestorIDs) e.addOverrides_forCellAtIndex_ancestorIDs(t, 0, r); else if ("function" == typeof e.addOverrides_ancestorIDs) e.addOverrides_ancestorIDs(t, r); else {
                var n = r.join("/"), o = MSOverrideValue.alloc().initWithName_value(n + "_stringValue", t);
                if (e.addOverrideValue(o), e.overrides && e.setOverrides) {
                    var i = e.overrides();
                    e.setOverrides(i);
                }
            }
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.addOverrides = r;
    }, function(e, t) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        t.FillType = {
            Solid: 0,
            Gradient: 1,
            Pattern: 4,
            Noise: 5
        }, t.GradientType = {
            Linear: 0,
            Radial: 1,
            Circular: 2
        }, t.PatternFillType = {
            Tile: 0,
            Fill: 1
        }, t.NoiseFillType = {
            Original: 0,
            Black: 1,
            White: 2,
            Color: 3
        }, t.BorderLineCapsStyle = {
            Butt: 0,
            Round: 1,
            Square: 2
        }, t.BorderLineJoinStyle = {
            Miter: 0,
            Round: 1,
            Bevel: 2
        }, t.LineDecorationType = {
            None: 0,
            OpenedArrow: 1,
            ClosedArrow: 2,
            Bar: 3
        }, t.BlurType = {
            GaussianBlur: 0,
            MotionBlur: 1,
            ZoomBlur: 2,
            BackgroundBlur: 3
        }, t.BorderPosition = {
            Center: 0,
            Inside: 1,
            Outside: 2,
            Both: 3
        }, t.MaskMode = {
            Outline: 0,
            Alpha: 1
        }, t.BooleanOperation = {
            None: -1,
            Union: 0,
            Subtract: 1,
            Intersect: 2,
            Difference: 3
        }, t.ExportOptionsFormat = {
            PNG: "png",
            JPG: "jpg",
            TIFF: "tiff",
            PDF: "pdf",
            EPS: "eps",
            SVG: "svg"
        }, t.BlendingMode = {
            Normal: 0,
            Darken: 1,
            Multiply: 2,
            ColorBurn: 3,
            Lighten: 4,
            Screen: 5,
            ColorDodge: 6,
            Overlay: 7,
            SoftLight: 8,
            HardLight: 9,
            Difference: 10,
            Exclusion: 11,
            Hue: 12,
            Saturation: 13,
            Color: 14,
            Luminosity: 15
        }, t.TextAlignment = {
            Left: 0,
            Right: 1,
            Center: 2,
            Justified: 3
        }, t.TextBehaviour = {
            Auto: 0,
            Fixed: 1
        }, t.CurvePointMode = {
            Straight: 1,
            Mirrored: 2,
            Disconnected: 4,
            Asymmetric: 3
        }, t.ModelClasses = {
            MSModelObject: "MSModelObject",
            MSModelBase: "MSModelBase",
            MSDocumentData: "MSDocumentData",
            MSLayer: "MSLayer",
            MSShapeGroup: "MSShapeGroup",
            MSLayerGroup: "MSLayerGroup",
            MSPage: "MSPage",
            MSTextLayer: "MSTextLayer",
            MSBitmapLayer: "MSBitmapLayer",
            MSSliceLayer: "MSSliceLayer",
            MSArtboardGroup: "MSArtboardGroup",
            MSOvalShape: "MSOvalShape",
            MSRectangleShape: "MSRectangleShape",
            MSStarShape: "MSStarShape",
            MSPolygonShape: "MSPolygonShape",
            MSTriangleShape: "MSTriangleShape",
            MSStyle: "MSStyle",
            MSStyleBorder: "MSStyleBorder",
            MSStyleFill: "MSStyleFill",
            MSStyleShadow: "MSStyleShadow",
            MSStyleInnerShadow: "MSStyleInnerShadow",
            MSStyleBlur: "MSStyleBlur",
            MSStyleBorderOptions: "MSStyleBorderOptions",
            MSStyleColorControls: "MSStyleColorControls",
            MSStyleReflection: "MSStyleReflection"
        };
    }, function(e, t, r) {
        "use strict";
        function n(e) {
            return e.class() === MSTextLayer;
        }
        function o(e) {
            return e.class() === MSLayerGroup;
        }
        function i(e) {
            return e.class() === MSSymbolInstance;
        }
        function a(e) {
            return n(e) || o(e) || i(e);
        }
        function l(e) {
            return (0, f.filter)(e, a).count();
        }
        function s(e, t) {
            var r = NSMutableArray.alloc().init();
            return (0, f.iterate)(e, function(e) {
                var a = NSMutableArray.alloc().init();
                null != t && a.addObjectsFromArray(t), n(e) ? (a.addObject(e.objectID()), r.addObject({
                    layer: e,
                    path: a
                })) : i(e) ? (a.addObject(e.objectID()), r.addObjectsFromArray(s(e.symbolMaster().layers(), a))) : o(e) && r.addObjectsFromArray(s(e.layers()));
            }), r;
        }
        function u(e, t) {
            var r = NSMutableArray.alloc().init();
            return (0, f.iterate)(e, function(e) {
                n(e) || i(e) ? r.addObject(e) : o(e) && r.addObject(t.resolveTextAncestorIDsFromSymbol(e));
            }), r;
        }
        function c(e, t, r) {
            var n = void 0;
            r && (n = e.textAlignment(), e.setTextAlignment(S.TextAlignment.Left)), e.setIsEditingText(!0), 
            e.setStringValue(t), e.setIsEditingText(!1), e.finishEditing(), r && void 0 !== n && e.setTextAlignment(n);
        }
        function d(e) {
            var t = e.parentArtboard();
            if (t) {
                var r = e.absoluteRect(), n = r.x(), o = r.y(), i = r.width(), a = r.height(), l = t.absoluteRect(), s = l.width() - n + l.x(), u = l.height() - o + l.y(), c = e.rect();
                i > s && (c.size.width = s), a > u && (c.size.height = u), e.setTextBehaviour(S.TextBehaviour.Fixed), 
                e.setHeightIsClipped(!0), e.setRect(c);
            }
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.isTextLayer = n, t.isGroup = o, t.isSymbol = i, t.getLayersCount = l, t.flatten = s, 
        t.filterLayers = u, t.set = c, t.setFixed = d;
        var f = r(1), S = r(10);
    }, function(e, t, r) {
        "use strict";
        function n(e) {
            return e.class() !== MSLayerGroup && e.class() !== MSSliceLayer;
        }
        function o(e) {
            return (0, i.filter)(e, n);
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.filterLayers = o;
        var i = r(1);
    }, function(e, t, r) {
        "use strict";
        function n(e) {
            if (e && e.__esModule) return e;
            var t = {};
            if (null != e) for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
            return t.default = e, t;
        }
        function o(e, t, r, n, o, i) {
            var a = ICUtils.objectToJSONString({
                name: i,
                paths: n,
                path: o
            });
            t.setValue_forKey_onLayer_forPluginIdentifier(a, "json-plugin-data", r, e);
        }
        function i(e, t, r, n, i, a, l) {
            o(e, t, r, i, a, l), r.class() === MSTextLayer && s.set(r, n, !1);
        }
        function a(e, t, r, n, o) {
            var i = ICUtils.objectToJSONString(n), a = JSON.parse(t.valueForKey_onLayer_forPluginIdentifier("json-files", r, e.identifier()));
            a || (a = []);
            for (var l = String(i.sha1()), s = !1, u = void 0, c = 0; c < a.length; ++c) {
                var d = a[c];
                if (d.hash === l && String(d.name) === String(o)) {
                    s = !0, u = d.path;
                    break;
                }
            }
            if (!s) {
                u = String(NSUUID.UUID().UUIDString()) + ".json";
                var f = String(e.settingsDocumentsPath()) + "/" + u;
                i.writeToFile_atomically_encoding_error(f, !0, NSUTF8StringEncoding, null), a.push({
                    path: u,
                    name: o,
                    hash: l
                }), t.setValue_forKey_onLayer_forPluginIdentifier(ICUtils.objectToJSONString(a), "json-files", r, e.identifier());
            }
            var S = {
                path: u,
                name: o,
                json: n
            };
            return {
                file: S,
                files: a
            };
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.setMetaData = o, t.setupLayer = i, t.createFile = a;
        var l = r(11), s = n(l);
    }, function(e, t) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        t.DUPLICATE_IDENTIFIER = "com.invisionlabs.duplicate";
    } ]);
});