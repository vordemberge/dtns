//
//  Sync.h
//  Sync
//
//  Created by Tomáš Hanáček on 4/12/16.
//  Copyright © 2016 InVision LABS. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for Sync.
FOUNDATION_EXPORT double SyncVersionNumber;

//! Project version string for Sync.
FOUNDATION_EXPORT const unsigned char SyncVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Sync/PublicHeader.h>

