sketchApi.uploadArtboards = function(surfaceId, previewsMetadata, uploadAll, title, isEnterprise, teamSubdomain, callback) {
  var callbackID = this.registerListener(callback);
  if (surfaceId === undefined) {
    surfaceId = null;
  }

  if (previewsMetadata) {
    previewsMetadata = JSON.stringify(previewsMetadata);
  } else {
    previewsMetadata = null;
  }

  SketchApi.surface$_uploadArtboardsWithSurfaceId_previewsMetadata_uploadAll_title_teamSubdomain_callbackID_(surfaceId, previewsMetadata, uploadAll, title, teamSubdomain, callbackID);
}

sketchApi.getUserTeams = function(callback) {
  var callbackID = this.registerCallback(callback);
  SketchApi.surface$_userTeamsWithCallbackID_(callbackID);
}

sketchApi.getUserInfo = function(callback) {
  var callbackID = this.registerCallback(callback);
  SketchApi.surface$_userInfoWithCallbackID_(callbackID);
}

sketchApi.isLoggedIn = function() {
  return Boolean(SketchApi.surface$_isLoggedIn());
}

sketchApi.login = function(callback) {
  var callbackID = this.registerCallback(callback);
  SketchApi.surface$_loginWithCallbackID_(callbackID);
}

sketchApi.logout = function(callback) {
  var callbackID = this.registerCallback(callback);
  SketchApi.surface$_logoutWithCallbackID_(callbackID);
}

sketchApi.debugForceError = function(code) {
  SketchApi.surface$_debugForceErrorWithCode_(code);
}

sketchApi.isApiV7 = function() {
  return Boolean(SketchApi.surface$_isApiV7());
}
