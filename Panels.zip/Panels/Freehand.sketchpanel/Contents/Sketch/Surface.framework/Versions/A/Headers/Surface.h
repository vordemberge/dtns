//
//  Surface.h
//  Surface
//
//  Created by Tomáš Hanáček on 11/1/16.
//  Copyright © 2016 InVision LABS. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for Surface.
FOUNDATION_EXPORT double SurfaceVersionNumber;

//! Project version string for Surface.
FOUNDATION_EXPORT const unsigned char SurfaceVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Surface/PublicHeader.h>


