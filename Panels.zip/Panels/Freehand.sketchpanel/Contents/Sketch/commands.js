!function(e, o) {
    if ("object" == typeof exports && "object" == typeof module) module.exports = o(); else if ("function" == typeof define && define.amd) define([], o); else {
        var t = o();
        for (var r in t) ("object" == typeof exports ? exports : e)[r] = t[r];
    }
}(this, function() {
    return function(e) {
        function o(r) {
            if (t[r]) return t[r].exports;
            var n = t[r] = {
                exports: {},
                id: r,
                loaded: !1
            };
            return e[r].call(n.exports, n, n.exports, o), n.loaded = !0, n.exports;
        }
        var t = {};
        return o.m = e, o.c = t, o.p = "", o(0);
    }([ function(e, o) {
        "use strict";
        function t(e) {
            var o = e.panel;
            o.show(), o.callback(null);
        }
        Object.defineProperty(o, "__esModule", {
            value: !0
        }), o.upload = t;
    } ]);
});